#include <stdio.h>
#define N 10
int main(int argc, char const *argv[]) 
{
	int z;
	int q=5;
	int _ao09;
	int 103;
	unsigned int x=1000.68;
	unsigned int y=13.08e+10;
	unsigned int z=133e80;
	int y=1.2e1.2;
	if(z==100)
	{
		if(q==1000)
		{
			z=q;
		}
	}
	else
	{
		if(q==1000)
		{
			z=q;
		}
	}
	for(int i =0;i<10;i++)
	{
		printf("hi\n");
	}
	while(i!=+10)
	{
		i++;
	}
	if(x>=10)
	{ 
		return 1; 
	}
	return 0;
}