#include <stdio.h>
#define N 10
int main(int argc, char const *argv[]) 
{
	int z;
	int q=5;
	int _ao09;
	int 103;
	unsigned int x=1000.68;
	unsigned int y=13.08e+10;
	unsigned int z=133e80;
	if(a==b)
	{
		printf("Hello");
	}
	return 0;
}