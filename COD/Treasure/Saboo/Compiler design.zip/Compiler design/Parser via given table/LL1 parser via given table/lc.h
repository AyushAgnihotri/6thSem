#define plus 1
#define mult 2
#define op	 3
#define cp   4
#define id 	 5
#define nl   6
#define oth 7