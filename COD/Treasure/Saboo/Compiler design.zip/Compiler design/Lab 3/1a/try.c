char id, id;
int id, id, int;
float atul;
float id
int harsh, vikas;
int int;