int a=20;
int id=val;
char id,id=id;
unsigned int id=5;
int c=d;
