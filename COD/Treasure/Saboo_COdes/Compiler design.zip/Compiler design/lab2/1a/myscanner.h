#define VALID 1
#define OTHER 2
#define NEWLINE 3
