#define UNSIGNED 1
#define SIGNED 2
#define OTHER 3