#define id 1
#define plus 2
#define star 3
#define op 4
#define cp 5
#define dollar 6